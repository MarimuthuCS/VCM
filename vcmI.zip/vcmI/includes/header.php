<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>VCM</title>
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	<link rel="stylesheet" id="bootstrap-css" href="css/bootstrap.css" type="text/css" media="all">
	<link rel="stylesheet" id="awesome-font-css" href="css/font-awesome.css" type="text/css" media="all">
	<link rel="stylesheet" id="ionicon-font-css" href="css/ionicon.css" type="text/css" media="all">
	<link rel="stylesheet" id="slick-slider-css" href="css/slick.css" type="text/css" media="all">
	<link rel="stylesheet" id="slick-theme-css" href="css/slick-theme.css" type="text/css" media="all">
	<link rel="stylesheet" id="magnific-popup-css" href="css/magnific-popup.css" type="text/css" media="all">
	<link rel="stylesheet" id="industris-style-css" href="style.css" type="text/css" media="all">

	<link rel="shortcut icon" href="favicon.png">
	<link
		rel="stylesheet"
		href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

</head>

<body>
	<div id="page" class="site">
		<div class="collapse searchbar" id="searchbar">
			<div class="search-area">
				<div class="container">
					<div class="row">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<div class="input-group">
								<input type="text" class="form-control" placeholder="Search for...">
								<span class="input-group-btn">
									<button class="btn btn-primary" type="button">Go!</button>
								</span>
							</div>
							<!-- /input-group -->
						</div>
						<!-- /.col-lg-6 -->
					</div>
				</div>
			</div>
		</div>
		<header id="site-header" class="site-header mobile-header-blue header-style-1">
			<div id="header_topbar" class="header-topbar md-hidden sm-hidden clearfix">
				<div class="container-custom">
					<div class="row">
						<div class="col-md-8">
							<!-- Info on Topbar -->
							<ul class="topbar-left">
								<li><i class="icon ion-md-pin"></i>Perumagoundenpalayam, Sulur, Coimbatore, Tamil Nadu – 641401</li>
								<li><i class="icon ion-md-call"></i>+91 9876543210</li>
								<li><i class="icon ion-md-mail"></i>info@svcm.com</li>
							</ul>
						</div>
						<!-- Info on topbar close -->
						<div class="col-md-4">
							<ul class="topbar-right pull-right">
								<li class="toggle_search topbar-search"><a href="#"><i class="icon ion-md-search"></i></a></li>
								<li class="topbar-login"><a href="#"> Login </a></li>
								<li class="topbar-languages"><a href="#"> English <i class="icon ion-ios-arrow-down"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- Top bar close -->
			<div class="main-header md-hidden sm-hidden">
				<div class="container-custom">
					<div class="row">
						<div class="col-md-3">
							<div class="logo-brand">
								<a href="index.html">
									<!-- <img src="images/logo.png" alt="industris"> -->
									<h2 class="fw-bold mb-0 logo-text">VCM</h2>
								</a>
							</div>
						</div>
						<div class="col-md-9">
							<div class="main-navigation">
								<ul id="primary-menu" class="menu">
									<li class="menu-item "><a href="#home">Home</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item current-menu-item page_item current_page_item"><a href="index.html">Home 1</a></li>
			        						<li class="menu-item"><a href="index-2.html">Home 2</a></li>
			        						<li class="menu-item"><a href="index-3.html">Home 3</a></li>
			        						<li class="menu-item"><a href="index-4.html">Home 4</a></li>
			        					</ul> -->
									</li>
									<li class="menu-item"><a href="#about">About Us</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item"><a href="about-us.html">About Us</a></li>
			        						<li class="menu-item menu-item-has-children"><a href="events.html">Events</a>
				        						<ul class="">
				        							<li class="menu-item"><a href="events.html">Event</a></li>
				        							<li class="menu-item"><a href="events-detail.html">Event Detail</a></li>
				        						</ul>
				        					</li>
					        				<li class="menu-item menu-item-has-children"><a href="shop.html">Shop</a>
					        					<ul class="sub-menu">
					        						<li class="menu-item"><a href="shop.html">Shop</a></li>
					        						<li class="menu-item"><a href="shop-detail.html">Shop Detail</a></li>
					        						<li class="menu-item"><a href="cart.html">Cart</a></li>
					        						<li class="menu-item"><a href="checkout.html">Checkout</a></li>
					        					</ul>
					        				</li>
			        						<li class="menu-item"><a href="faq.html">FAQ's</a></li>
			        						<li class="menu-item"><a href="gallery.html">Gallery</a></li>
			        						<li class="menu-item"><a href="404-page.html">404 Pages</a></li>
			        						<li class="menu-item"><a href="comming-soon.html">Comming Soon</a></li>
			        						<li class="menu-item"><a href="login.html">Login</a></li>
			        						<li class="menu-item"><a href="typography.html">Typography</a></li>
			        						<li class="menu-item"><a href="carrer.html">Career Page</a></li>
			        						<li class="menu-item"><a href="corporate-governance.html">Corporate Governance</a></li>
			        						<li class="menu-item"><a href="history.html">History</a></li>
			        						<li class="menu-item"><a href="our-team.html">Our Team</a></li>
			        						<li class="menu-item"><a href="partner-clients.html">Partner Clients</a></li>
			        						<li class="menu-item"><a href="contact-us.html">Contact Us</a></li>
			        					</ul> -->
									</li>
									<li class="menu-item menu-item-has-children"><a href="#">Products</a>
										<ul class="sub-menu">
											<li class="menu-item"><a href="#">Cotton Fabric</a></li>
											<li class="menu-item"><a href="#">Rayon Cotton</a></li>
											<li class="menu-item"><a href="#">Polyester Blend </a></li>
											<li class="menu-item"><a href="#">Custom Weaves </a></li>
										</ul>
									</li>
									<li class="menu-item "><a href="#">Gallary</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item"><a href="project.html">Project 1</a></li>
			        						<li class="menu-item"><a href="project-2.html">Project 2</a></li>
			        						<li class="menu-item"><a href="project-detail.html">Project Detail</a></li>
			        					</ul> -->
									</li>
									<li class="menu-item "><a href="#contactus">Contact Us</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item current-menu-item page_item current_page_item"><a href="news.html">News 1</a></li>
			        						<li class="menu-item"><a href="news-2.html">News 2</a></li>
			        						<li class="menu-item"><a href="post.html">News Detail</a></li>
			        					</ul> -->
									</li>
								</ul>
								<a href="#" class="btn btn-primary">Get a quote<i class="icon ion-md-paper-plane"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Main header start -->

			<!-- Mobile header start -->
			<div class="mobile-header">
				<div class="container-custom">
					<div class="row">
						<div class="col-xs-6">
							<div class="logo-brand-mobile">
								<a href="index.html"><img src="images/logo.png" alt="industris"></a>
							</div>
						</div>
						<div class="col-xs-6">
							<div id="mmenu_toggle">
								<button></button>
							</div>
						</div>
						<div class="col-xs-12">
							<div class="mobile-nav">
								<ul id="primary-menu-mobile" class="mobile-menu">
									<li class="menu-item "><a href="#home">Home</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item page current-menu-item current_page_item"><a href="index.html">Home 1</a></li>
			        						<li class="menu-item"><a href="index-2.html">Home 2</a></li>
			        						<li class="menu-item"><a href="index-3.html">Home 3</a></li>
			        						<li class="menu-item"><a href="index-4.html">Home 4</a></li>
			        					</ul> -->
									</li>
									<li class="menu-item "><a href="#about">About Us</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item"><a href="about-us.html">About Us</a></li>
			        						<li class="menu-item menu-item-has-children"><a href="events.html">Events</a>
				        						<ul class="">
				        							<li class="menu-item"><a href="events.html">Event</a></li>
				        							<li class="menu-item"><a href="events-detail.html">Event Detail</a></li>
				        						</ul>
				        					</li>
					        				<li class="menu-item menu-item-has-children"><a href="shop.html">Shop</a>
					        					<ul class="sub-menu">
					        						<li class="menu-item"><a href="shop.html">Shop</a></li>
					        						<li class="menu-item"><a href="shop-detail.html">Shop Detail</a></li>
					        						<li class="menu-item"><a href="cart.html">Cart</a></li>
					        						<li class="menu-item"><a href="checkout.html">Checkout</a></li>
					        					</ul>
					        				</li>
			        						<li class="menu-item"><a href="faq.html">FAQ's</a></li>
			        						<li class="menu-item"><a href="gallery.html">Gallery</a></li>
			        						<li class="menu-item"><a href="404-page.html">404 Pages</a></li>
			        						<li class="menu-item"><a href="comming-soon.html">Comming Soon</a></li>
			        						<li class="menu-item"><a href="login.html">Login</a></li>
			        						<li class="menu-item"><a href="typography.html">Typography</a></li>
			        						<li class="menu-item"><a href="carrer.html">Career Page</a></li>
			        						<li class="menu-item"><a href="corporate-governance.html">Corporate Governance</a></li>
			        						<li class="menu-item"><a href="history.html">History</a></li>
			        						<li class="menu-item"><a href="our-team.html">Our Team</a></li>
			        						<li class="menu-item"><a href="partner-clients.html">Partner Clients</a></li>
			        						<li class="menu-item"><a href="contact-us.html">Contact Us</a></li>
			        					</ul> -->
									</li>
									<li class="menu-item menu-item-has-children"><a href="#">Products</a>
										<ul class="sub-menu">
											<li class="menu-item"><a href="#">Cotton Fabric</a></li>
											<li class="menu-item"><a href="#">Rayon Cotton</a></li>
											<li class="menu-item"><a href="#">Polyester Blend </a></li>
											<li class="menu-item"><a href="#">Custom Weaves </a></li>
										</ul>
									</li>
									<li class="menu-item "><a href="#">Gallery</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item"><a href="project.html">Project 1</a></li>
			        						<li class="menu-item"><a href="project-2.html">Project 2</a></li>
			        						<li class="menu-item"><a href="project-detail.html">Project Detail</a></li>
			        					</ul> -->
									</li>
									<li class="menu-item "><a href="news.html">Contact Us</a>
										<!-- <ul class="sub-menu">
			        						<li class="menu-item"><a href="news.html">News 1</a></li>
			        						<li class="menu-item"><a href="news-2.html">News 2</a></li>
			        						<li class="menu-item"><a href="post.html">News Detail</a></li>
			        					</ul> -->
									</li>
								</ul>
								<a href="#" class="btn btn-primary">Get a quote<i class="icon ion-md-paper-plane"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- Mobile header start -->